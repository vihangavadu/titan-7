#!/usr/bin/env python3
"""TITAN OS — VPS Full Deployment Script
Connects to VPS via paramiko and deploys the entire codebase."""

import paramiko
import os
import sys
import time
import stat

VPS_IP = "72.62.72.48"
VPS_USER = "root"
VPS_PASS = "Chilaw@123@llm"
LOCAL_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ISO_BASE = os.path.join(LOCAL_BASE, "iso", "config", "includes.chroot", "opt", "titan")

def get_ssh():
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(VPS_IP, username=VPS_USER, password=VPS_PASS, timeout=15)
    return ssh

def run_cmd(ssh, cmd, timeout=60):
    stdin, stdout, stderr = ssh.exec_command(cmd, timeout=timeout)
    out = stdout.read().decode(errors='replace').strip()
    err = stderr.read().decode(errors='replace').strip()
    rc = stdout.channel.recv_exit_status()
    return rc, out, err

def upload_dir(sftp, local_dir, remote_dir):
    """Recursively upload a directory."""
    count = 0
    for root, dirs, files in os.walk(local_dir):
        # Skip __pycache__, .git, .venv, node_modules
        dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', '.venv', 'node_modules', '.idea')]
        
        rel = os.path.relpath(root, local_dir)
        remote_path = remote_dir if rel == '.' else f"{remote_dir}/{rel}".replace('\\', '/')
        
        try:
            sftp.stat(remote_path)
        except FileNotFoundError:
            sftp.mkdir(remote_path)
        
        for f in files:
            if f.endswith(('.pyc', '.pyo')):
                continue
            local_file = os.path.join(root, f)
            remote_file = f"{remote_path}/{f}"
            try:
                sftp.put(local_file, remote_file)
                count += 1
            except Exception as e:
                print(f"  SKIP {remote_file}: {e}")
    return count

def main():
    print("=" * 60)
    print("  TITAN OS — VPS Full Deployment")
    print(f"  Target: {VPS_USER}@{VPS_IP}")
    print("=" * 60)
    
    # Phase 1: Connect and setup SSH key
    print("\n[Phase 1] Connecting and setting up SSH key...")
    ssh = get_ssh()
    
    pubkey_path = os.path.expanduser("~/.ssh/id_ed25519.pub")
    if os.path.exists(pubkey_path):
        with open(pubkey_path) as f:
            pubkey = f.read().strip()
        run_cmd(ssh, f'mkdir -p /root/.ssh && chmod 700 /root/.ssh && echo "{pubkey}" >> /root/.ssh/authorized_keys && chmod 600 /root/.ssh/authorized_keys && sort -u /root/.ssh/authorized_keys -o /root/.ssh/authorized_keys')
        print("  [+] SSH key installed")
    
    # Phase 2: Create directory structure
    print("\n[Phase 2] Creating directory structure...")
    dirs = [
        "/opt/titan",
        "/opt/titan/core",
        "/opt/titan/apps",
        "/opt/titan/config",
        "/opt/titan/scripts",
        "/opt/titan/android",
        "/opt/titan/assets/motions",
        "/opt/titan/models",
        "/opt/titan/data",
        "/opt/titan/data/voice_clones",
        "/opt/titan/logs",
        "/opt/titan/training",
        "/opt/titan/research",
        "/opt/titan/tests",
    ]
    run_cmd(ssh, "mkdir -p " + " ".join(dirs))
    print(f"  [+] Created {len(dirs)} directories")
    
    # Phase 3: Upload codebase
    print("\n[Phase 3] Uploading codebase files...")
    sftp = ssh.open_sftp()
    
    total = 0
    
    # Upload ISO includes (this is the deployable codebase)
    iso_dirs = {
        "core": "/opt/titan/core",
        "apps": "/opt/titan/apps",
        "config": "/opt/titan/config",
    }
    
    for subdir, remote in iso_dirs.items():
        local = os.path.join(ISO_BASE, subdir)
        if os.path.isdir(local):
            print(f"  Uploading {subdir}/...")
            n = upload_dir(sftp, local, remote)
            total += n
            print(f"    [{n} files]")
    
    # Upload scripts from repo scripts/
    scripts_local = os.path.join(LOCAL_BASE, "scripts")
    if os.path.isdir(scripts_local):
        print("  Uploading scripts/...")
        n = upload_dir(sftp, scripts_local, "/opt/titan/scripts")
        total += n
        print(f"    [{n} files]")
    
    # Upload src/core files (may have newer versions than ISO)
    src_core = os.path.join(LOCAL_BASE, "src", "core")
    if os.path.isdir(src_core):
        print("  Uploading src/core/ (overlay)...")
        n = upload_dir(sftp, src_core, "/opt/titan/core")
        total += n
        print(f"    [{n} files]")
    
    # Upload src/apps files
    src_apps = os.path.join(LOCAL_BASE, "src", "apps")
    if os.path.isdir(src_apps):
        print("  Uploading src/apps/ (overlay)...")
        n = upload_dir(sftp, src_apps, "/opt/titan/apps")
        total += n
        print(f"    [{n} files]")
    
    # Upload research docs
    research = os.path.join(LOCAL_BASE, "research-resources")
    if os.path.isdir(research):
        print("  Uploading research-resources/...")
        n = upload_dir(sftp, research, "/opt/titan/research")
        total += n
        print(f"    [{n} files]")
    
    # Upload tests
    tests_local = os.path.join(LOCAL_BASE, "tests")
    if os.path.isdir(tests_local):
        print("  Uploading tests/...")
        n = upload_dir(sftp, tests_local, "/opt/titan/tests")
        total += n
        print(f"    [{n} files]")
    
    # Upload training files
    training_local = os.path.join(LOCAL_BASE, "training")
    if os.path.isdir(training_local):
        print("  Uploading training/...")
        n = upload_dir(sftp, training_local, "/opt/titan/training")
        total += n
        print(f"    [{n} files]")
    
    # Upload profgen
    profgen_local = os.path.join(LOCAL_BASE, "profgen")
    if os.path.isdir(profgen_local):
        print("  Uploading profgen/...")
        n = upload_dir(sftp, profgen_local, "/opt/titan/profgen")
        total += n
        print(f"    [{n} files]")
    
    # Upload docs
    docs_local = os.path.join(LOCAL_BASE, "docs")
    if os.path.isdir(docs_local):
        print("  Uploading docs/...")
        n = upload_dir(sftp, docs_local, "/opt/titan/docs")
        total += n
        print(f"    [{n} files]")
    
    sftp.close()
    print(f"\n  [+] Total files uploaded: {total}")
    
    # Phase 4: Install system packages
    print("\n[Phase 4] Installing system packages...")
    pkg_cmd = """export DEBIAN_FRONTEND=noninteractive && \
apt-get update -qq && \
apt-get install -y -qq \
    python3 python3-pip python3-venv python3-dev \
    git curl wget unzip jq htop tmux screen \
    build-essential libssl-dev libffi-dev \
    redis-server \
    ffmpeg \
    v4l2loopback-dkms \
    gstreamer1.0-tools gstreamer1.0-plugins-base gstreamer1.0-plugins-good \
    python3-opencv \
    nodejs npm \
    lxc dnsmasq-base iptables bridge-utils \
    mesa-utils \
    nginx \
    2>&1 | tail -5"""
    
    print("  Installing (this takes 2-3 minutes)...")
    rc, out, err = run_cmd(ssh, pkg_cmd, timeout=300)
    print(f"  {out}")
    if rc == 0:
        print("  [+] System packages installed")
    else:
        print(f"  [!] Some packages may have failed: {err[-200:]}")
    
    # Phase 5: Install Python packages
    print("\n[Phase 5] Installing Python packages...")
    pip_cmd = """pip3 install --break-system-packages -q \
    flask flask-cors flask-socketio \
    requests aiohttp httpx \
    PyQt6 \
    paramiko \
    psutil \
    cryptography \
    pyyaml \
    Pillow \
    numpy \
    2>&1 | tail -5"""
    
    rc, out, err = run_cmd(ssh, pip_cmd, timeout=300)
    print(f"  {out}")
    print("  [+] Python packages installed")
    
    # Phase 6: Install Ollama
    print("\n[Phase 6] Installing Ollama...")
    rc, out, _ = run_cmd(ssh, "which ollama 2>/dev/null && echo ALREADY_INSTALLED || echo NOT_INSTALLED")
    if "NOT_INSTALLED" in out:
        print("  Downloading Ollama...")
        rc, out, err = run_cmd(ssh, "curl -fsSL https://ollama.com/install.sh | sh 2>&1 | tail -5", timeout=120)
        print(f"  {out}")
    else:
        print("  [+] Ollama already installed")
    
    # Phase 7: Configure services
    print("\n[Phase 7] Configuring services...")
    
    # Redis
    run_cmd(ssh, "systemctl enable redis-server && systemctl start redis-server")
    rc, out, _ = run_cmd(ssh, "redis-cli ping")
    print(f"  Redis: {out}")
    
    # Ollama
    run_cmd(ssh, "systemctl enable ollama && systemctl start ollama")
    time.sleep(3)
    rc, out, _ = run_cmd(ssh, "curl -s http://localhost:11434/api/tags | head -c 100")
    print(f"  Ollama: {'running' if rc == 0 and out else 'starting...'}")
    
    # Phase 8: Set permissions and create symlinks
    print("\n[Phase 8] Setting permissions...")
    run_cmd(ssh, "chmod -R +x /opt/titan/scripts/ 2>/dev/null; chmod +x /opt/titan/apps/*.py 2>/dev/null; chmod +x /opt/titan/core/*.py 2>/dev/null")
    
    # Create titan.env if not exists
    rc, _, _ = run_cmd(ssh, "test -f /opt/titan/config/titan.env && echo EXISTS")
    if rc != 0:
        run_cmd(ssh, """cat > /opt/titan/config/titan.env << 'EOF'
TITAN_ROOT=/opt/titan
TITAN_VERSION=9.2
TITAN_ENV=production
OLLAMA_HOST=http://localhost:11434
REDIS_URL=redis://localhost:6379
API_PORT=5000
EOF""")
        print("  [+] titan.env created")
    
    # Phase 9: Verification
    print("\n[Phase 9] Running verification...")
    verify_cmd = r"""
PASS=0; FAIL=0
check() { if eval "$1" 2>/dev/null; then echo "  ✓ $2"; PASS=$((PASS+1)); else echo "  ✗ $2"; FAIL=$((FAIL+1)); fi; }

check "test -d /opt/titan/core" "core/ directory exists"
check "test -d /opt/titan/apps" "apps/ directory exists"
check "test -d /opt/titan/scripts" "scripts/ directory exists"
check "test -d /opt/titan/config" "config/ directory exists"

# Count files
CORE_COUNT=$(find /opt/titan/core -name '*.py' | wc -l)
APPS_COUNT=$(find /opt/titan/apps -name '*.py' | wc -l)
echo "  → Core modules: $CORE_COUNT .py files"
echo "  → App files: $APPS_COUNT .py files"

check "[ $CORE_COUNT -gt 50 ]" "core has 50+ modules"
check "[ $APPS_COUNT -gt 5 ]" "apps has 5+ files"

# KYC files
check "test -f /opt/titan/core/kyc_core.py" "kyc_core.py exists"
check "test -f /opt/titan/core/kyc_enhanced.py" "kyc_enhanced.py exists"
check "test -f /opt/titan/core/kyc_voice_engine.py" "kyc_voice_engine.py exists"
check "test -f /opt/titan/core/waydroid_sync.py" "waydroid_sync.py exists"
check "test -f /opt/titan/core/titan_api.py" "titan_api.py exists"
check "test -f /opt/titan/core/cockpit_daemon.py" "cockpit_daemon.py exists"

# Services
check "systemctl is-active redis-server >/dev/null 2>&1" "Redis running"
check "systemctl is-active ollama >/dev/null 2>&1" "Ollama running"

# Python
check "python3 -c 'import flask'" "Flask importable"
check "python3 -c 'import redis'" "Redis python module"

echo ""
echo "═══════════════════════════════════════════"
echo "  Results: $PASS passed, $FAIL failed"
echo "═══════════════════════════════════════════"
"""
    rc, out, err = run_cmd(ssh, verify_cmd, timeout=30)
    print(out)
    
    ssh.close()
    print("\n[DONE] VPS deployment complete!")
    print("  SSH: ssh root@72.62.72.48")

if __name__ == "__main__":
    main()
