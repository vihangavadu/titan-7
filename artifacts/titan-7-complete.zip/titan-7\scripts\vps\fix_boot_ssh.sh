#!/bin/bash
# TITAN VPS Boot Fix — Run in RECOVERY MODE with filesystem at /mnt/sdb1
set -e
ROOT="/mnt/sdb1"

echo "=== TITAN VPS BOOT FIX ==="
echo ""

# 1. Create SSH safety net service
echo "--- Creating SSH safety net service ---"
cat > "${ROOT}/etc/systemd/system/titan-ssh-safety.service" << 'SVCEOF'
[Unit]
Description=TITAN SSH Safety Net - Ensures SSH is always reachable
After=network-online.target nftables.service
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c 'nft add rule inet titan_firewall input tcp dport 22 accept 2>/dev/null; nft add rule inet titan_firewall input tcp dport 3389 accept 2>/dev/null; iptables -I INPUT -p tcp --dport 22 -j ACCEPT 2>/dev/null; echo [TITAN-SSH-SAFETY] SSH+RDP rules enforced'

[Install]
WantedBy=multi-user.target
SVCEOF
ln -sf /etc/systemd/system/titan-ssh-safety.service "${ROOT}/etc/systemd/system/multi-user.target.wants/titan-ssh-safety.service" 2>/dev/null || true
echo "  Created titan-ssh-safety.service"

# 2. Fix titan-dns.service with Unbound fallback
echo "--- Fixing titan-dns.service ---"
cat > "${ROOT}/etc/systemd/system/titan-dns.service" << 'DNSEOF'
[Unit]
Description=TITAN DNS Privacy Activation
After=network-online.target unbound.service
Wants=network-online.target
BindsTo=unbound.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c 'sleep 3; if systemctl is-active --quiet unbound; then echo "nameserver 127.0.0.1" > /etc/resolv.conf; echo "[TITAN-DNS] Using Unbound"; else echo "nameserver 1.1.1.1" > /etc/resolv.conf; echo "nameserver 8.8.4.4" >> /etc/resolv.conf; echo "[TITAN-DNS] Unbound not ready, using fallback"; fi'

[Install]
WantedBy=multi-user.target
DNSEOF
echo "  Fixed titan-dns.service"

# 3. Ensure resolv.conf has working DNS as fallback
echo "--- Setting fallback resolv.conf ---"
cat > "${ROOT}/etc/resolv.conf" << 'RESEOF'
nameserver 1.1.1.1
nameserver 8.8.4.4
nameserver 153.92.2.6
RESEOF
echo "  Set fallback resolv.conf"

# 4. Disable conflicting network managers (if not already done)
echo "--- Ensuring single network manager ---"
rm -f "${ROOT}/etc/systemd/system/multi-user.target.wants/NetworkManager.service" 2>/dev/null
rm -f "${ROOT}/etc/systemd/system/multi-user.target.wants/networking.service" 2>/dev/null
# Mask NetworkManager
ln -sf /dev/null "${ROOT}/etc/systemd/system/NetworkManager.service" 2>/dev/null || true
echo "  Disabled: NetworkManager, networking"
echo "  Keeping: systemd-networkd (for netplan)"

# 5. Ensure systemd-networkd is enabled
ln -sf /lib/systemd/system/systemd-networkd.service "${ROOT}/etc/systemd/system/multi-user.target.wants/systemd-networkd.service" 2>/dev/null || true
echo "  Enabled: systemd-networkd"

# 6. Ensure cloud-init networking works
echo "--- Ensuring cloud-init network config ---"
if [ -f "${ROOT}/etc/netplan/50-cloud-init.yaml" ]; then
    echo "  Netplan config exists: OK"
else
    echo "  WARNING: No netplan config found!"
fi

# 7. Verify SSH is enabled
echo "--- Verifying SSH ---"
ls -la "${ROOT}/etc/systemd/system/multi-user.target.wants/ssh.service" 2>/dev/null && echo "  SSH: enabled" || echo "  SSH: NOT ENABLED!"

# 8. Verify final state
echo ""
echo "=== FINAL STATE ==="
echo "Enabled services:"
ls "${ROOT}/etc/systemd/system/multi-user.target.wants/" 2>/dev/null | sort
echo ""
echo "Masked services:"
find "${ROOT}/etc/systemd/system/" -maxdepth 1 -type l -lname '/dev/null' -exec basename {} \; 2>/dev/null
echo ""
echo "=== FIX COMPLETE — Exit recovery mode and reboot ==="
