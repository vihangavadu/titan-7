# TITAN OS — Master vs Workspace Gap Report
## `titan-7-master` vs `titan-7` (current workspace)

**Date:** Feb 23, 2026 | **Auditor:** Cascade AI

---

## STRUCTURAL DIFFERENCE

The two repos have **fundamentally different layouts**:

| Aspect | `titan-7-master` | `titan-7` (workspace) |
|--------|-------------------|----------------------|
| Source code location | `iso/config/includes.chroot/opt/titan/` | `src/` |
| Has `src/` directory | ❌ No | ✅ Yes |
| Root-level build scripts | ✅ 20+ scripts | ❌ Missing |
| Root-level docs | ✅ 6 extra .md files | Moved to `docs/` |
| Core modules in ISO chroot | 38 files | N/A (in `src/core/` instead) |
| Dedicated `hostinger-dev/` | ❌ No | ✅ Yes |
| `docs/operational-playbook/` | ❌ No | ✅ Yes (15 files) |

**Key insight:** `titan-7-master` stores source code inside the ISO build tree (`iso/config/includes.chroot/opt/titan/`), while `titan-7` has a clean `src/` directory that gets copied into the ISO during build. The workspace (`titan-7`) is the more organized, development-friendly layout.

---

## SECTION 1: FILES IN `titan-7-master` BUT MISSING FROM WORKSPACE

### 1.1 Root-Level Build & Deploy Scripts (HIGH — 20 files)

These scripts exist at the root of `titan-7-master` but are completely absent from the workspace:

| File | Size | Purpose |
|------|------|---------|
| `build_docker.sh` | 11.7KB | Docker-based ISO build |
| `build_docker.ps1` | 13.1KB | PowerShell Docker build |
| `build_docker.bat` | 6.4KB | Windows Docker build launcher |
| `build_local.sh` | 13.8KB | Local (non-Docker) ISO build |
| `build_final.sh` | 4.8KB | Final build step |
| `build_direct.bat` | 949B | Direct build launcher |
| `build_now.bat` | 1KB | Quick build launcher |
| `build_simple.bat` | 2.9KB | Simplified build |
| `deploy_vps.sh` | 17.4KB | Full VPS deployment script |
| `vps_complete_sync.sh` | 10KB | VPS sync/update script |
| `vps_upgrade_v8.sh` | 8.8KB | V8 upgrade script |
| `install_ai_enhancements.sh` | 5.2KB | AI stack installer (Ollama, etc.) |
| `install_self_hosted_stack.sh` | 23.3KB | Full self-hosted stack installer |
| `install_titan.sh` | 670B | Quick Titan installer |
| `install_titan_wsl.sh` | 4.9KB | WSL installer |
| `patch_backend_v8.sh` | 2.6KB | V8 backend patch |
| `api_scan.sh` | 1.3KB | API endpoint scanner |
| `check_api_routes.sh` | 516B | API route checker |
| `launch-lucid-titan.ps1` | 1.3KB | PowerShell launcher |
| `askpass.sh` / `ssh_pass.sh` / `ssh_connect.sh` / `do_ssh.sh` | ~1KB ea. | SSH helpers |

**Impact:** Missing entire Docker build pipeline and VPS deployment toolchain. Operators cannot build ISO from Windows Docker or deploy to VPS without these.

### 1.2 Root-Level Documentation (MEDIUM — 6 files)

| File | Size | Purpose |
|------|------|---------|
| `APP_ARCHITECTURE_V81.md` | 7.7KB | V8.1 app restructure doc (workspace has `docs/APP_ARCHITECTURE.md`) |
| `BUILD_GUIDE.md` | 13KB | Comprehensive build guide |
| `DOCKER_BUILD.md` | 7KB | Docker build instructions |
| `ISO_BUILD_EXECUTION_GUIDE.md` | 6KB | Step-by-step ISO build |
| `README_V81.md` | 3.7KB | V8.1 release notes |
| `TITAN_APP_RESTRUCTURE.md` | 7.8KB | App restructure planning doc |

### 1.3 Root-Level `vps_hw_shield.c` (LOW)

| File | Size | Notes |
|------|------|-------|
| `vps_hw_shield.c` | 39.5KB | Root copy — workspace has `src/lib/vps_hw_shield.c` |

### 1.4 Docs Missing from Workspace `docs/` (MEDIUM — 6 files)

| File in master `docs/` | In workspace `docs/`? | Notes |
|-------------------------|----------------------|-------|
| `56_MODULE_OPERATIONAL_GUIDE.md` | ✅ as `MODULE_REFERENCE.md` | Same file, renamed |
| `CLONE_AND_CONFIGURE_100_PERCENT_VERIFICATION.md` | ❌ **MISSING** | C&C verification checklist |
| `GUI_CODEBASE_CROSSREF_REPORT.md` | ❌ **MISSING** | GUI code cross-reference |
| `GUI_UX_AUDIT_V81.md` | ❌ **MISSING** | GUI UX audit |
| `MIGRATION_INTEGRITY_VERIFIER.md` | ❌ **MISSING** | Migration verification |
| `TITAN_V76_VS_V81_DEEP_ANALYSIS.md` | ❌ **MISSING** | Version comparison |

### 1.5 Plans Directory (LOW)

| File | In workspace? |
|------|--------------|
| `plans/BUILD_ISO_CAPABILITY_VERIFICATION.md` | ❌ **MISSING** |

### 1.6 Sample Profiles (LOW)

Master has `profiles/Browser Profile Forensic Analysis Plan.txt` and a generated profile in `profiles/69d61dd9b07f8fe19ee5c3b79e4e56ac/` with real cache2 entries. Workspace `profiles/` is empty.

### 1.7 Apps in Master ISO Chroot Not in Workspace `src/apps/` (MEDIUM)

| File | In workspace? | Notes |
|------|--------------|-------|
| `titan_launcher.py` | ❌ **MISSING** | Python GUI launcher (workspace has shell `src/bin/titan-launcher`) |
| `README_DevHub.md` | ❌ **MISSING** | Dev Hub documentation |
| `README_SystemEditor.md` | ❌ **MISSING** | System Editor docs |
| `launch_dev_hub.bat` | ❌ **MISSING** | Dev Hub Windows launcher |
| `launch_dev_hub.sh` | ❌ **MISSING** | Dev Hub Linux launcher |
| `requirements.txt` | ❌ **MISSING** | Apps dependency list |
| `test_install.bat` | ❌ **MISSING** | Install tester |

### 1.8 ISO Config Differences (LOW)

Both repos have essentially the same `iso/config/` structure (hooks, includes.chroot, package-lists). Master additionally has a root-level `config/includes.chroot/` with 4 extra hardening files:
- `etc/security/limits.d/disable-cores.conf`
- `etc/sysctl.d/99-titan-stealth.conf`
- `usr/lib/dracut/modules.d/99ramwipe/module-setup.sh`
- `usr/lib/dracut/modules.d/99ramwipe/titan-wipe.sh`

The **RAM wipe module** (`99ramwipe/`) is notably missing from the workspace ISO config — this is a forensic security feature that wipes RAM on shutdown.

### 1.9 `Dockerfile.build` (LOW — identical)

Both repos have `Dockerfile.build` (same size: 6160 bytes).

---

## SECTION 2: FILES IN WORKSPACE BUT MISSING FROM `titan-7-master`

### 2.1 Entire `src/` Directory Structure (EXPECTED)

The workspace has a clean `src/` layout that master lacks:
- `src/core/` — 48 files (38 in master's ISO chroot)
- `src/apps/` — 15 files
- `src/bin/` — 8 files
- `src/extensions/` — 5 files
- `src/lib/` — 5 C files
- `src/testing/` — 7 files
- `src/profgen/` — 7 files
- `src/vpn/` — 4 files
- `src/branding/` — 11 files
- `src/assets/` — 2 files
- `src/config/` — 2 files
- `src/build.sh` — master build script

### 2.2 Core Modules in Workspace but NOT in Master ISO (HIGH — 10 files)

| Module | Size | Notes |
|--------|------|-------|
| `chromium_cookie_engine.py` | 49KB | Chromium cookie synthesis |
| `cookie_forge.py` | 27KB | Cookie generation engine |
| `ga_triangulation.py` | 19KB | Google Analytics triangulation |
| `journey_simulator.py` | 11KB | User journey simulation |
| `mullvad_vpn.py` | — | Mullvad VPN integration |
| `network_jitter.py` | — | Network timing jitter |
| `network_shield.py` | 45KB | Network shield (duplicate of loader?) |
| `network_shield_loader.py` | — | eBPF loader |
| `ollama_bridge.py` | — | Ollama AI bridge |
| `payment_preflight.py` | — | Payment pre-flight checks |

Plus additional modules truncated from the listing. **Master's ISO chroot has only 38 core files vs workspace's 48.**

### 2.3 Docs Only in Workspace (MEDIUM)

| File | Notes |
|------|-------|
| `docs/AUTOMATION_SYSTEM.md` | Automation documentation |
| `docs/DEEP_AUDIT_V81.md` | Deep code audit |
| `docs/MODULE_CERBERUS_DEEP_DIVE.md` | Cerberus deep dive |
| `docs/MODULE_GENESIS_DEEP_DIVE.md` | Genesis deep dive |
| `docs/OPERATOR_GUIDE.md` | Operator guide |
| `docs/TITAN_OS_TECHNICAL_REPORT_FULL.md` | Full technical report |
| `docs/VPS_CROSS_REFERENCE.md` | VPS cross-reference |
| `docs/operational-playbook/` | 15 playbook files |

### 2.4 Other Workspace-Only Directories

| Directory | Files | Notes |
|-----------|-------|-------|
| `hostinger-dev/` | 6 files | Hostinger VPS dev tools + MCP config |
| `scripts/install/` | 5 files | Install subscripts |
| `scripts/vps/` | 3 files | VPS management scripts |
| `scripts/deploy_full.sh` | 1 file | Full deployment script |
| `TITAN_GAP_AUDIT.md` | 1 file | Gap audit report |

---

## SECTION 3: CORE MODULE DRIFT (Content Differences)

The workspace has bug fixes applied that master does NOT have:

| Module | Fix Applied in Workspace | Master Status |
|--------|--------------------------|---------------|
| `profile_realism_engine.py` | GMP ABI → `x86_64-msvc-x64` | ❌ Still has old ABI |
| `genesis_core.py` | Seeded `_rng.paretovariate()` + `/opt/titan` path | ❌ Unseeded + `/opt/lucid-empire` |
| `advanced_profile_generator.py` | GPU auto-selection from hardware_profile | ❌ Hardcoded RTX 3060 |
| `webgl_angle.py` | VIRGL GPU profile added | ❌ Missing VIRGL |
| `audio_hardener.py` | FPP overrides instead of RFP | ❌ Still has `resistFingerprinting=True` |
| `verify_deep_identity.py` | `/opt/titan` path | ❌ `/opt/lucid-empire` |
| `integration_bridge.py` | `/opt/titan` paths | ❌ `/opt/lucid-empire` |
| `fingerprint_injector.py` | `/opt/titan` path | ❌ `/opt/lucid-empire` |
| `handover_protocol.py` | `/opt/titan` path | ❌ `/opt/lucid-empire` |
| `titan_master_verify.py` | `/opt/titan` path | ❌ `/opt/lucid-empire` |
| `Makefile` | `/opt/titan` install paths | ❌ `/opt/lucid-empire` |
| `build_ebpf.sh` | `/opt/titan` output dir | ❌ `/opt/lucid-empire` |

**All workspace bug fixes need to be backported to master's ISO chroot files.**

---

## SECTION 4: PRIORITY SUMMARY

### P0 — Critical (Blocks Build/Deploy)

| # | Gap | Direction | Impact |
|---|-----|-----------|--------|
| 1 | 20+ build/deploy scripts missing from workspace | master → workspace | Cannot build Docker ISO or deploy to VPS |
| 2 | `config/includes.chroot/` RAM wipe module missing | master → workspace | Forensic security gap |
| 3 | 10+ core modules missing from master ISO | workspace → master | Master ISO ships incomplete codebase |
| 4 | All workspace bug fixes not in master | workspace → master | Master has known bugs |

### P1 — High

| # | Gap | Direction | Impact |
|---|-----|-----------|--------|
| 5 | 5 docs missing from workspace (`CLONE_AND_CONFIGURE`, `GUI_UX_AUDIT`, etc.) | master → workspace | Missing verification/audit docs |
| 6 | `titan_launcher.py` Python GUI launcher missing from workspace | master → workspace | No Python-based launcher |
| 7 | `apps/requirements.txt` missing from workspace | master → workspace | No dependency pinning for apps |
| 8 | Dev Hub files missing from workspace | master → workspace | No Dev Hub tooling |

### P2 — Medium

| # | Gap | Direction | Impact |
|---|-----|-----------|--------|
| 9 | 7 docs only in workspace (`DEEP_AUDIT`, `operational-playbook/`, etc.) | workspace → master | Master missing detailed audits |
| 10 | `hostinger-dev/` only in workspace | workspace → master | VPS management tools not in master |
| 11 | `scripts/install/`, `scripts/vps/` only in workspace | workspace → master | Deployment helpers missing |
| 12 | Root-level planning docs not in workspace | master → workspace | Build verification plan missing |
| 13 | Sample profile data not in workspace | master → workspace | No reference profile for testing |

### P3 — Low (Structural/Cosmetic)

| # | Gap |
|---|-----|
| 14 | `research-resources/` (master) = `docs/research/` (workspace) — renamed, same content |
| 15 | `vps_hw_shield.c` at root in master, in `src/lib/` in workspace |
| 16 | `Dockerfile.build` identical in both |
| 17 | `.gitignore` differs (910B workspace vs 24B master) |

---

## SECTION 5: RECOMMENDED ACTIONS

### Immediate (sync both repos)

1. **Copy build scripts from master to workspace:** All 20+ root-level `.sh`, `.bat`, `.ps1` build/deploy scripts
2. **Copy missing docs from master:** `CLONE_AND_CONFIGURE_100_PERCENT_VERIFICATION.md`, `GUI_CODEBASE_CROSSREF_REPORT.md`, `GUI_UX_AUDIT_V81.md`, `MIGRATION_INTEGRITY_VERIFIER.md`, `TITAN_V76_VS_V81_DEEP_ANALYSIS.md`
3. **Copy RAM wipe module** from master's `config/includes.chroot/usr/lib/dracut/modules.d/99ramwipe/`
4. **Copy Dev Hub files** from master's apps

### Backport to master

5. **Backport all bug fixes** from workspace `src/core/` → master `iso/config/includes.chroot/opt/titan/core/`
6. **Copy 10 missing core modules** from workspace → master ISO chroot
7. **Copy workspace-only docs** to master

---

*Generated: Feb 23, 2026 | Comparing titan-7-master with titan-7 workspace*
