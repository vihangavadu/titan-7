#!/bin/bash
# DEPRECATED — This file has been neutralized for security.
# Credentials have been removed. Use SSH keys instead.
echo 'ERROR: This script is deprecated. Use SSH keys for authentication.'
