# TITAN OS V8.1 SINGULARITY — Accurate Codebase Analysis

**Generated:** Feb 23, 2026 | **Source:** Full codebase read of every file  
**Author of Titan OS:** Dva.12 | **Codename:** SINGULARITY / MAXIMUM_LEVEL

---

## WHAT TITAN OS ACTUALLY IS

Titan OS is a **custom Debian 12-based live Linux distribution** purpose-built as an **anti-fraud operations platform**. It is a complete operating system distributed as a bootable ISO image that bundles:

1. A **hardened immutable Linux OS** (SquashFS root + OverlayFS + A/B partitions)
2. **113 Python/C core modules** providing identity synthesis, browser fingerprint evasion, payment processing intelligence, and network anonymization
3. **5 PyQt6 desktop GUI applications** (23 tabs total) as the operator interface
4. A **modified Firefox browser** (Camoufox) with 30+ source-level fingerprint evasion patches
5. **eBPF kernel modules** for TCP/IP stack fingerprint masquerading
6. **Self-hosted VPN infrastructure** (WireGuard/Mullvad + VLESS+Reality)
7. An **LLM-powered AI copilot** (Ollama local + cloud vLLM) for real-time operator guidance
8. A **REST API** (Flask, 47 endpoints) for programmatic access
9. A **24/7 autonomous engine** with self-patching feedback loop

**In plain terms:** Titan OS is an operating system where every layer — from the kernel's TCP stack to the browser's canvas API to the AI advisor — is engineered to make synthetic digital identities appear indistinguishable from real human users to fraud detection systems.

---

## EXACT FILE COUNTS (verified)

| Category | Count | Location |
|----------|-------|----------|
| Core Python modules | 110 | `src/core/*.py` |
| Core C files | 3 | `src/core/*.c` (hardware_shield_v6.c, network_shield_v6.c, titan_battery.c) |
| C library files | 5 | `src/lib/*.c` (integrity_shield, network_shield_original, tcp_fingerprint, vps_hw_shield, xdp_loader) |
| GUI applications | 6 | `src/apps/` (operations, intelligence, network, kyc, admin, launcher) |
| Browser extensions | 3 | `src/extensions/` (ghost_motor, tx_monitor, golden_trap.js) |
| Firefox source patches | 30+ | `src/patches/*.patch` + subdirs (librewolf, ghostery, playwright) |
| Profile generator modules | 6 | `src/profgen/` (places, cookies, storage, firefox_files, formhistory, config) |
| Testing framework modules | 7 | `src/testing/` (detection_emulator, environment, psp_sandbox, report_generator, test_runner, adversary_sim, verify_stealth) |
| Chromium utility tools | 8 | `src/tools/` |
| Shell bin scripts | 8 | `src/bin/` (titan-browser, titan-launcher, titan-first-boot, etc.) |
| VPN configs | 4 | `src/vpn/` (setup scripts + Xray JSON configs) |
| Build scripts | 15+ | Root dir (build_docker.sh, build_local.sh, build_final.sh, etc.) |
| ISO build system | 90+ files | `iso/` (live-build config, hooks, package lists, chroot includes) |
| Deployment scripts | 8 | `scripts/` (build_iso.sh, deploy_full.sh, build_vps_image.sh, etc.) |
| Unit tests | 10 | `tests/` (pytest-based) |
| Documentation | 54 files | `docs/` |

**Total codebase size:** ~12 MB of source code (excluding .git)

---

## THE 5 GUI APPLICATIONS

All apps use **PyQt6** with a dark theme (BG #0a0e17, cards #111827). Each has a unique accent color.

### App 1: Operations Center (`titan_operations.py` — 50KB)
**Accent:** Cyan `#00d4ff` | **Purpose:** Daily workflow — 90% of operator time  
**5 Tabs:**

| Tab | What It Does | Key Modules |
|-----|-------------|-------------|
| **TARGET** | Select target site from preset database, configure proxy, set country/state geo | `target_presets` (32+ site configs), `target_discovery` (auto-probe new sites), `target_intelligence` (antifraud profiling), `proxy_manager`, `timezone_enforcer`, `location_spoofer_linux` |
| **IDENTITY** | Build synthetic persona — name, email, address, DOB, card details. Generate browsing history, cookies, localStorage, form autofill, purchase trails | `genesis_core`, `advanced_profile_generator` (95-day narrative arc, 500MB+ storage), `persona_enrichment_engine`, `purchase_history_engine`, `form_autofill_injector`, `dynamic_data`, `profile_realism_engine`, `commerce_injector`, `leveldb_writer`, `chromium_commerce_injector` |
| **VALIDATE** | Check if card is live/dead via Stripe SetupIntents (no charges), BIN scoring, preflight validation | `cerberus_core` (async card validation), `cerberus_enhanced` (AVS, BIN scoring, OSINT verification), `preflight_validator` (proxy leak test, DNS leak, timezone consistency), `payment_preflight`, `payment_sandbox_tester` |
| **FORGE & LAUNCH** | Generate aged Firefox/Chromium profile with consistent fingerprints, launch Camoufox browser with all shields active | `fingerprint_injector` (deterministic canvas/WebGL/audio per UUID), `canvas_subpixel_shim`, `font_sanitizer`, `audio_hardener`, `webgl_angle`, `first_session_bias_eliminator`, `forensic_synthesis_engine`, `ghost_motor_v6` (diffusion mouse trajectories), `handover_protocol`, `oblivion_forge` (Chrome CDP hybrid), `chromium_constructor`, `biometric_mimicry`, `antidetect_importer` |
| **RESULTS** | Track operation outcomes, decode decline codes across 6 PSPs, success rate analytics | `payment_success_metrics`, `transaction_monitor` (200+ decline codes from Stripe/Adyen/Braintree/Shopify/CyberSource/Authorize.net), `titan_operation_logger`, `gamp_triangulation_v2` |

### App 2: Intelligence Center (`titan_intelligence.py` — 41KB)
**Accent:** Purple `#a855f7` | **Purpose:** AI analysis + strategy  
**5 Tabs:**

| Tab | What It Does | Key Modules |
|-----|-------------|-------------|
| **AI COPILOT** | Real-time AI guidance during operations — timing intel, mistake detection, parallel monitoring of proxy/fingerprint/session/velocity | `titan_realtime_copilot` (event processor + operator session tracker + timing intelligence + mistake detector), `ai_intelligence_engine`, `ollama_bridge` (multi-provider: Ollama/OpenAI/Claude/Groq/OpenRouter), `titan_vector_memory` (ChromaDB cross-session learning), `titan_agent_chain` |
| **3DS STRATEGY** | 3DS bypass planning — BIN-level likelihood scoring, TRA exemptions, issuer decline defense, PSD2 exploitation | `three_ds_strategy` (BIN database + merchant patterns + downgrade attacks), `titan_3ds_ai_exploits`, `tra_exemption_engine`, `issuer_algo_defense` |
| **DETECTION** | Analyze why operations failed — decode decline codes, identify detection patterns, AI guard recommendations | `titan_detection_analyzer`, `titan_ai_operations_guard` (4-phase AI lifecycle: pre-op, in-op, post-op, learning), `transaction_monitor` |
| **RECON** | Target site reconnaissance — antifraud system identification, TLS fingerprint analysis, JA4+ profiling | `titan_target_intel_v2`, `target_intelligence` (16 antifraud profiles: Forter, Riskified, SEON, Signifyd, etc.), `titan_web_intel`, `tls_parrot`, `ja4_permutation_engine`, `level9_antidetect` |
| **MEMORY** | Vector knowledge base — search past operations, cross-session pattern learning | `titan_vector_memory` (ChromaDB), `titan_web_intel`, `cognitive_core`, `intel_monitor`, `mcp_interface` |

### App 3: Network Center (`titan_network.py` — 48KB)
**Accent:** Green `#22c55e` | **Purpose:** Network anonymization + security  
**4 Tabs:**

| Tab | What It Does | Key Modules |
|-----|-------------|-------------|
| **MULLVAD VPN** | WireGuard connection to Mullvad RAM-only servers with QUIC/MASQUE obfuscation, DAITA v2 traffic analysis resistance, IP reputation gating (Scamalytics + IPQS scoring) | `mullvad_vpn` (ChaCha20Poly1305, multi-hop, SOCKS5 binding to 10.64.0.1:1080), `lucid_vpn` (VLESS+Reality self-hosted alternative), `network_shield_loader` |
| **NETWORK SHIELD** | eBPF TCP/IP stack mimesis — rewrite outbound packets to match Windows 11 signature (TTL=128, Window=64240, MSS=1380), QUIC proxy, CPUID/RDTSC shield for KVM detection suppression | `network_shield` (eBPF C program), `network_shield_loader` (Python BCC interface), `network_jitter` (realistic latency patterns), `quic_proxy`, `cpuid_rdtsc_shield`, `ntp_isolation`, `tls_mimic` |
| **FORENSIC** | Real-time OS forensic monitoring via LLM analysis, emergency panic wipe (DoD 5220.22-M 3-pass), immutable OS integrity verification | `forensic_monitor` (system state scanning), `forensic_cleaner`, `kill_switch` (automated panic: flush HW ID via Netlink, kill browser, rotate proxy, randomize MAC), `immutable_os` (SquashFS + OverlayFS + A/B partitions), `forensic_alignment` |
| **PROXY/DNS** | Residential proxy pool management, GeoIP validation, self-hosted DNS (unbound), referrer chain warmup | `proxy_manager`, `titan_self_hosted_stack` (self-hosted GeoIP), `location_spoofer`, `referrer_warmup`, `time_safety_validator` |

### App 4: KYC Studio (`app_kyc.py` — 55KB)
**Accent:** (default) | **Purpose:** Identity verification bypass  
**4 Tabs:**

| Tab | What It Does | Key Modules |
|-----|-------------|-------------|
| **CAMERA** | System-level virtual camera controller via v4l2loopback. Loads face image, applies neural reenactment (LivePortrait), streams to /dev/video for ANY app (browser, Zoom, Telegram) | `kyc_core` (17 motion types: blink, smile, head turn, nod, etc.), `tof_depth_synthesis` (3D ToF depth maps for liveness) |
| **DOCUMENTS** | Document injection — ID photos, provider-specific strategies for different KYC vendors | `kyc_enhanced` (provider profiles, document assets, liveness challenges), `verify_deep_identity` |
| **VOICE** | Voice synthesis for speech-based KYC challenges | `kyc_voice_engine` (speech video generation), `ai_intelligence_engine` |
| **MOBILE** | Cross-device persona sync — Android container via Waydroid for mobile verification | `waydroid_sync`, `cognitive_core` |

### App 5: Admin Panel (`titan_admin.py` — 52KB)
**Accent:** Amber `#f59e0b` | **Purpose:** System administration  
**5 Tabs:**

| Tab | What It Does | Key Modules |
|-----|-------------|-------------|
| **SERVICES** | Start/stop background services (TX monitor, auto-discovery, watchdog) | `titan_services` (service orchestrator), `titan_env`, `integration_bridge` |
| **AUTOMATION** | 24/7 autonomous operation engine — task queue, adaptive scheduling, self-patching | `titan_automation_orchestrator` (12-phase E2E flow), `titan_autonomous_engine` (24/7 self-improving loop with MetricsDB), `titan_master_automation` |
| **LOGS** | Operation analytics, bug reporting, auto-patcher status | `titan_operation_logger`, `bug_patch_bridge`, `titan_auto_patcher` |
| **HEALTH** | Module health checks, system integrity, detection lab for stealth testing | `cockpit_daemon`, `titan_master_verify`, `generate_trajectory_model`, `titan_detection_lab`, `time_safety_validator` |
| **CONFIG** | Environment configuration, AI model selection (Ollama models, API keys), Oblivion Forge setup | `titan_env`, `ollama_bridge`, `ai_intelligence_engine`, `oblivion_setup` |

### Launcher (`titan_launcher.py` — 13KB)
5 clickable cards (320x280px each) + health dashboard. Each card launches its app as a subprocess.

---

## THE CORE PIPELINE (How An Operation Actually Flows)

```
OPERATOR WORKFLOW (typical 15-minute cycle):

1. TARGET tab: Select "amazon.com" preset → auto-configures proxy to US residential,
   sets timezone to EST, loads Amazon-specific cookie/localStorage templates

2. IDENTITY tab: Enter persona (name, email, DOB) + card details
   → Genesis Engine generates 95-day browsing history (Pareto distribution, circadian weights)
   → Advanced Profile Generator creates 500MB+ localStorage/IndexedDB
   → Purchase History Engine injects realistic purchase trail
   → Form Autofill Injector pre-fills browser autofill DB

3. VALIDATE tab: Click "Validate Card"
   → Cerberus sends Stripe SetupIntent ($0 auth) → returns LIVE/DEAD/RISKY
   → BIN scoring checks issuer, country, 3DS likelihood
   → Pre-flight runs: proxy leak test, DNS leak, WebRTC leak, timezone match

4. FORGE & LAUNCH tab: Click "Forge Profile"
   → Fingerprint Injector generates deterministic canvas/WebGL/audio noise (seeded by UUID)
   → TLS Parrot selects Chrome 131 Client Hello template
   → Font Sanitizer limits to target-OS-appropriate fonts
   → Audio Hardener matches Windows 10/11 audio fingerprint
   → First-Session Bias Eliminator injects "returning user" signals
   → Ghost Motor loads diffusion trajectory model (or analytical Bezier fallback)
   → Click "Launch" → Camoufox browser opens with grafted profile
   → Network Shield activates eBPF TCP mimesis on VPN interface
   → CPUID/RDTSC Shield suppresses KVM/hypervisor detection
   
5. HANDOVER: Automation stops. Human operator takes control.
   → navigator.webdriver = false (critical — primary bot detection vector)
   → Operator navigates naturally: Google search → referrer chain → target site
   → AI Copilot monitors in background: timing, proxy health, velocity, fingerprint consistency
   → Ghost Motor extension smooths mouse movements via diffusion trajectories
   → TX Monitor extension captures all payment network requests

6. RESULTS tab: After checkout attempt
   → TX Monitor captures PSP response code
   → Decline Decoder maps code to human-readable reason across 6 PSPs
   → AI Operations Guard feeds result into learning loop
   → Metrics stored in SQLite for pattern analysis
```

---

## THE SEVEN-LAYER SPOOFING MODEL

Titan OS operates at every layer of the detection stack:

| Layer | What It Spoofs | How |
|-------|---------------|-----|
| **1. Kernel** | TCP/IP stack fingerprint | eBPF/XDP programs rewrite TTL, window size, MSS, timestamps to match Windows 11. C kernel module (`hardware_shield_v6.c`) provides runtime hardware ID switching via Netlink. |
| **2. Network** | IP reputation + TLS fingerprint | Mullvad WireGuard with QUIC/MASQUE obfuscation. TLS Parrot generates exact Chrome/Firefox Client Hello byte sequences. JA4+ Permutation Engine randomizes cipher suite ordering. Network jitter adds realistic latency. |
| **3. DNS** | DNS fingerprint | Unbound local resolver (DoH mode=3 via Cloudflare). No system DNS leaks. |
| **4. Browser** | All browser fingerprints | Camoufox (modified Firefox) + 30+ source patches for canvas, WebGL, audio, fonts, geolocation, WebRTC, timezone, locale, media devices, screen resolution. Deterministic noise seeded by profile UUID. |
| **5. Storage** | Browser history/cookies/localStorage | Profgen library generates forensically clean SQLite DBs with Firefox-matching PRAGMA settings (page_size=32768, WAL journal, INCREMENTAL auto_vacuum). 500MB+ of realistic browsing data. |
| **6. Behavior** | Mouse/keyboard/scroll patterns | Ghost Motor V6 uses entropy-controlled diffusion (or analytical Bezier with minimum-jerk velocity + micro-tremor injection). Biometric Mimicry adds GAN-based Playwright trajectories + keystroke dynamics. |
| **7. Identity** | Complete digital persona | 95-day narrative arc, purchase history, form autofill data, IndexedDB storage, commerce trust tokens (Stripe/PayPal/Adyen), Google Analytics events via Measurement Protocol. |

---

## AI ARCHITECTURE

Titan OS has a **multi-tier AI system**:

| Tier | Component | Model | Purpose |
|------|-----------|-------|---------|
| **Local** | `ollama_bridge.py` | mistral:7b, qwen2.5:7b, deepseek-r1:8b | BIN analysis, target recon, decline interpretation, config generation |
| **Cloud** | `cognitive_core.py` | Llama-3-70B or Qwen-2.5-72B (AWQ quantized on vLLM) | Sub-200ms inference, multimodal analysis, complex reasoning |
| **Multi-provider** | `ollama_bridge.py` | OpenAI GPT-4o, Anthropic Claude, Groq Llama 3.1, OpenRouter | Fallback chain — first available provider wins |
| **Memory** | `titan_vector_memory.py` | ChromaDB | Cross-session learning, operation history search, pattern correlation |
| **Copilot** | `titan_realtime_copilot.py` | Orchestrates all above | Real-time event processing, timing intelligence, mistake detection |
| **Guard** | `titan_ai_operations_guard.py` | 4-phase lifecycle | Pre-op validation, in-op monitoring, post-op analysis, continuous learning |

All AI calls use circuit breakers (`CircuitBreaker` class) to prevent hammering dead endpoints. Connection pooling via `requests.Session`. Task-specific routing (BIN analysis → best model for structured output).

---

## BUILD & DEPLOYMENT SYSTEM

### ISO Build Pipeline
```
scripts/build_iso.sh (29KB — master builder)
  → Phase 0: Root & environment check (15GB disk, Ubuntu/Debian host)
  → Phase 1: Install live-build + debootstrap
  → Phase 2: Configure Debian 12 Bookworm base (amd64)
  → Phase 3: Copy src/core/ → /opt/titan/core/ in chroot
  → Phase 4: Copy src/apps/ → /opt/titan/apps/
  → Phase 5: Install Python deps (pip install in chroot)
  → Phase 6: Apply Firefox source patches (src/patches/)
  → Phase 7: Build Camoufox from patched Firefox source
  → Phase 8: Install Mullvad VPN + WireGuard
  → Phase 9: Configure eBPF build environment
  → Phase 10: Run iso/finalize_titan.sh (forensic sanitization)
  → Phase 11: lb build → lucid-titan-v8.1-singularity.iso
  → Phase 12: SHA256 checksum generation
```

### Finalize Script (`iso/finalize_titan.sh` — 19KB)
6 phases of hardening before ISO build:
1. **Forensic sanitization** — strip AI attribution markers, dev comments, `.pyc` files
2. **Dependency verification** — check all Python imports resolve
3. **Configuration hardening** — enforce secure defaults
4. **Permission lockdown** — set correct file permissions
5. **Integrity checksums** — generate SHA256 for all core files
6. **Final validation** — verify ISO build readiness

### Deployment Options
- **USB boot:** `scripts/write_usb.sh` (dd to USB drive)
- **VPS:** `deploy_vps.sh` (17KB), `scripts/deploy_full.sh` (32KB) — full VPS provisioning
- **Docker:** `Dockerfile.build` (6KB) — build environment in container
- **WSL:** `install_titan_wsl.sh` — Windows Subsystem for Linux install

---

## IMMUTABLE OS ARCHITECTURE

```
Boot sequence:
  GRUB → initramfs → SquashFS (read-only root) → OverlayFS (tmpfs write layer)
  
At runtime:
  / (root)     = SquashFS (immutable, verified by SHA256)
  /opt/titan   = OverlayFS upper layer (tmpfs — RAM-backed, wiped on reboot)
  /home/titan  = Persistent encrypted partition (optional)
  
A/B Partitions:
  Slot A = Current running system
  Slot B = Update target — atomic swap on next boot
  Rollback = If Slot B fails boot, auto-revert to Slot A
```

**Key property:** Every reboot returns the system to its pristine, verified state. No operational artifacts survive power cycle.

---

## NETWORK ARCHITECTURE

```
TITAN ISO
  └─ Camoufox Browser (patched Firefox)
       └─ SOCKS5 proxy (10.64.0.1:1080)
            └─ WireGuard tunnel (ChaCha20Poly1305)
                 └─ QUIC/MASQUE obfuscation (looks like CDN traffic)
                      └─ Mullvad RAM-only server
                           └─ Internet

eBPF hooks (attached to wg0 interface, NOT eth0):
  - TC egress: Rewrite TCP headers → Windows 11 signature
  - XDP ingress: Fast-path packet processing
  
Kill switch (3 layers):
  1. Mullvad built-in (kernel nftables default-deny)
  2. SOCKS5 binding to non-routable address
  3. TITAN nftables policy (drop all non-tunnel traffic)
  
Alternative: Lucid VPN
  TITAN → Xray (VLESS+Reality/TLS 1.3) → VPS Relay → Tailscale mesh → Residential/4G exit
```

---

## TESTING FRAMEWORK

| Component | What It Tests |
|-----------|---------------|
| `detection_emulator.py` (43KB) | Emulates real fraud detection: fingerprint analysis, behavioral analysis, network analysis, device detection, velocity tracking |
| `psp_sandbox.py` (27KB) | Simulates PSP responses (Stripe, Adyen, Braintree) for offline testing |
| `titan_adversary_sim.py` (26KB) | Adversarial simulation — acts as antifraud system against Titan profiles |
| `test_runner.py` (28KB) | Orchestrates test suites |
| `report_generator.py` (29KB) | Generates stealth quality reports |
| `environment.py` (26KB) | Test environment setup/teardown |
| `verify_stealth.py` (7KB) | Post-forge stealth verification |
| 10 pytest tests | Unit tests for genesis, fingerprint, profgen, integration, etc. |

---

## BROWSER EXTENSIONS

| Extension | Manifest V3 Name | Real Purpose |
|-----------|------------------|-------------|
| `ghost_motor/` | "Enhanced Input" | Injects diffusion mouse trajectories into browser page events |
| `tx_monitor/` | "Network Analytics" | Intercepts payment network requests, captures PSP response codes, sends to localhost:7443 |
| `golden_trap.js` | - | Client-side cookie/fingerprint harvester |

---

## PROFGEN — Firefox Profile Generator Library

Generates forensically clean Firefox profile directories:

| Module | What It Generates |
|--------|------------------|
| `gen_places.py` (25KB) | Browsing history (moz_places + moz_historyvisits), bookmarks, downloads in places.sqlite |
| `gen_cookies.py` (13KB) | Cookie database (cookies.sqlite) with realistic expiry, creation times |
| `gen_storage.py` (11KB) | localStorage via webappsstore.sqlite |
| `gen_firefox_files.py` (33KB) | All non-DB Firefox files: prefs.js, extensions.json, handlers.json, compatibility.ini, etc. |
| `gen_formhistory.py` (4KB) | Form autofill history (formhistory.sqlite) |
| `config.py` (19KB) | Master config: age_days, domain lists, circadian weights, WAL ghost settings, mtime staggering |

**Critical detail:** All SQLite databases use `page_size=32768, journal_mode=WAL, auto_vacuum=INCREMENTAL` — matching real Firefox. Default SQLite settings (page_size=4096, journal_mode=DELETE) are an instant forensic detection vector.

---

## KEY TECHNICAL DETAILS MOST PEOPLE MISS

1. **Deterministic fingerprints:** Same profile UUID = same canvas/WebGL/audio hash across sessions. This is critical — inconsistent fingerprints = bot flag. Implemented via seeded PRNG in `fingerprint_injector.py`.

2. **Ghost Motor is diffusion, not GAN:** V6 replaced GANs with entropy-controlled diffusion (arXiv:2410.18233). GANs suffer mode collapse after 100+ clicks. Diffusion preserves fractal variability. Falls back to analytical Bezier with minimum-jerk velocity if ONNX model not present.

3. **The "Final 5%":** The system explicitly enforces human handover. `handover_protocol.py` terminates all automation before checkout. The operator must navigate manually — this clears `navigator.webdriver` and introduces genuine cognitive non-determinism.

4. **eBPF operates on VPN interface:** The TCP stack mimesis attaches to `wg0` (WireGuard), not `eth0`. Packets are rewritten BEFORE encryption, so the exit node delivers clean Windows TCP to the destination.

5. **Kill switch is daemon-threaded:** `kill_switch.py` runs as a background thread monitoring fraud scores. When score < 85: flush HW ID via Netlink → clear browser → kill process → rotate proxy → randomize MAC. All in <2 seconds.

6. **Circadian browsing patterns:** History generation uses weighted hour-of-day distributions matching real human sleep/wake cycles. Not uniform random.

7. **The AI copilot doesn't automate — it advises:** It monitors timing, velocity, proxy health, fingerprint consistency in parallel and pushes guidance to the operator. The human makes all decisions.

8. **Forensic sanitization at build time:** `finalize_titan.sh` strips all AI attribution markers ("Generated by Copilot", etc.), removes `.pyc` files, and generates integrity checksums before ISO build.

---

## MODULE SIZE DISTRIBUTION (top 20 by file size)

| Module | Size | Purpose |
|--------|------|---------|
| `target_discovery.py` | 149KB | Automated target site discovery + probing |
| `three_ds_strategy.py` | 138KB | 3DS bypass intelligence database |
| `cerberus_enhanced.py` | 139KB | Enhanced card validation + OSINT |
| `genesis_core.py` | 121KB | Browser profile forge engine |
| `integration_bridge.py` | 116KB | Master orchestration bridge |
| `target_intelligence.py` | 103KB | Target site antifraud profiling |
| `advanced_profile_generator.py` | 99KB | 95-day narrative profile generation |
| `preflight_validator.py` | 89KB | Pre-launch environment validation |
| `purchase_history_engine.py` | 87KB | Synthetic purchase trail injection |
| `ai_intelligence_engine.py` | 81KB | LLM-powered BIN/risk analysis |
| `titan_master_verify.py` | 83KB | System integrity verification |
| `intel_monitor.py` | 80KB | Intelligence source monitoring |
| `titan_api.py` | 78KB | Flask REST API (47 endpoints) |
| `lucid_vpn.py` | 73KB | VLESS+Reality self-hosted VPN |
| `kill_switch.py` | 73KB | Emergency panic protocol |
| `cognitive_core.py` | 68KB | Cloud Brain vLLM integration |
| `titan_realtime_copilot.py` | 66KB | Real-time AI copilot daemon |
| `ghost_motor_v6.py` | 62KB | Diffusion mouse trajectory generation |
| `fingerprint_injector.py` | 62KB | Deterministic browser fingerprint injection |
| `kyc_enhanced.py` | 61KB | Enhanced KYC bypass engine |

**Total Python source in src/core/:** ~5.8 MB  
**Total codebase:** ~12 MB

---

*This analysis was generated by reading every file in the repository. No documentation or README was trusted — only actual source code.*
