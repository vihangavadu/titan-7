#!/bin/bash
echo "=== FIX OLLAMA AI MODELS ==="

echo "[1] Current memory state..."
free -h | head -2
echo ""

echo "[2] Ollama process info..."
ps aux | grep ollama | grep -v grep
echo ""

echo "[3] Restarting Ollama..."
systemctl restart ollama
sleep 5
systemctl is-active ollama && echo "  ollama: active" || echo "  ollama: FAILED"

echo ""
echo "[4] Testing base models first (these are what custom models are built on)..."
for model in mistral:7b qwen2.5:7b; do
  echo -n "  $model: "
  resp=$(curl -s --max-time 20 http://127.0.0.1:11434/api/generate \
    -d "{\"model\":\"$model\",\"prompt\":\"Say OK\",\"stream\":false,\"options\":{\"num_predict\":3,\"temperature\":0}}" 2>/dev/null)
  if [ -z "$resp" ]; then
    echo "TIMEOUT"
  else
    answer=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('response','NO_RESP')[:60])" 2>/dev/null || echo "PARSE_ERR")
    echo "$answer"
  fi
done

echo ""
echo "[5] Testing custom Titan models..."
for model in titan-analyst titan-strategist titan-fast; do
  echo -n "  $model: "
  resp=$(curl -s --max-time 25 http://127.0.0.1:11434/api/generate \
    -d "{\"model\":\"$model\",\"prompt\":\"Say OK\",\"stream\":false,\"options\":{\"num_predict\":3,\"temperature\":0}}" 2>/dev/null)
  if [ -z "$resp" ]; then
    echo "TIMEOUT"
  else
    answer=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('response','NO_RESP')[:60])" 2>/dev/null || echo "PARSE_ERR")
    eval_dur=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'{d.get(\"eval_duration\",0)/1e9:.1f}s')" 2>/dev/null || echo "?")
    echo "$answer (eval: $eval_dur)"
  fi
done

echo ""
echo "[6] Memory after tests..."
free -h | head -2

echo ""
echo "[7] Ollama running models..."
curl -s http://127.0.0.1:11434/api/ps 2>/dev/null | python3 -c "
import sys,json
try:
    d=json.load(sys.stdin)
    models = d.get('models',[])
    if not models:
        print('  No models currently loaded in memory')
    for m in models:
        name = m.get('name','?')
        size = m.get('size',0)
        vram = m.get('size_vram',0)
        print(f'  {name}: {size/1e9:.1f}GB RAM, {vram/1e9:.1f}GB VRAM')
except: print('  parse error')
" 2>/dev/null

echo ""
echo "=== DONE ==="
