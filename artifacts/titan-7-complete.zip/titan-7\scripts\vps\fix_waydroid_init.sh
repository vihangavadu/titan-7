#!/bin/bash
set -e
echo "=== FIX WAYDROID INIT ==="

# The issue: vndbinder node missing. Waydroid needs binder, hwbinder, vndbinder.
# On VPS kernels, only binder_linux module provides /dev/binder.
# We need to create binderfs mount with all 3 nodes.

echo "[1] Setting up binderfs..."

# Create binderfs mount point
mkdir -p /dev/binderfs

# Check if already mounted
if mountpoint -q /dev/binderfs 2>/dev/null; then
    echo "  binderfs already mounted"
else
    # Mount binderfs
    mount -t binder binder /dev/binderfs 2>/dev/null || {
        echo "  binderfs mount failed, trying alternative..."
        # Some kernels use 'binderfs' type
        mount -t binderfs binderfs /dev/binderfs 2>/dev/null || {
            echo "  binderfs not available in kernel"
            echo "  Trying to create binder nodes manually..."
        }
    }
fi

# Check if binder nodes exist
echo ""
echo "[2] Checking binder nodes..."
ls -la /dev/binder* 2>/dev/null
ls -la /dev/binderfs/ 2>/dev/null || true

# If binderfs is mounted, allocate the required nodes
if mountpoint -q /dev/binderfs 2>/dev/null; then
    echo ""
    echo "[3] Allocating binder nodes in binderfs..."
    for node in binder hwbinder vndbinder; do
        if [ ! -e "/dev/binderfs/$node" ]; then
            echo "$node" > /dev/binderfs/binder-control 2>/dev/null && echo "  Created: $node" || echo "  Failed: $node"
        else
            echo "  Exists: $node"
        fi
    done
fi

# Make persistent via fstab
if ! grep -q binderfs /etc/fstab 2>/dev/null; then
    echo "binder /dev/binderfs binder defaults 0 0" >> /etc/fstab 2>/dev/null || true
    echo "  Added binderfs to fstab"
fi

# Also try creating symlinks as fallback
if [ -e /dev/binder ] && [ ! -e /dev/binderfs/binder ]; then
    echo ""
    echo "[4] Creating symlink fallback..."
    mkdir -p /dev/binderfs
    for node in hwbinder vndbinder; do
        if [ ! -e "/dev/$node" ] && [ ! -e "/dev/binderfs/$node" ]; then
            ln -sf /dev/binder /dev/$node 2>/dev/null && echo "  Symlink: /dev/$node -> /dev/binder" || true
        fi
    done
fi

# Configure waydroid to use the correct binder path
echo ""
echo "[5] Configuring waydroid binder path..."
mkdir -p /var/lib/waydroid
cat > /var/lib/waydroid/waydroid.cfg << 'EOF'
[waydroid]
images_path = /var/lib/waydroid/images
EOF

# Now try downloading the image manually if waydroid init still fails
echo ""
echo "[6] Attempting waydroid init..."
waydroid init -s GAPPS -f 2>&1 | tail -15 || {
    echo ""
    echo "[6b] waydroid init failed. Downloading images manually..."
    
    mkdir -p /var/lib/waydroid/images
    
    # Get the latest image URLs from OTA
    echo "  Fetching image URLs from https://ota.waydro.id/system..."
    
    # Download system image
    ARCH="x86_64"
    OTA_URL="https://ota.waydro.id/system"
    
    # Try direct download of LineageOS 18.1 GAPPS x86_64
    SYSTEM_URL="https://sourceforge.net/projects/waydroid/files/images/system/lineage/waydroid_x86_64/lineage-18.1-20240927-GAPPS-waydroid_x86_64-system.zip/download"
    VENDOR_URL="https://sourceforge.net/projects/waydroid/files/images/vendor/waydroid_x86_64/lineage-18.1-20240927-MAINLINE-waydroid_x86_64-vendor.zip/download"
    
    if [ ! -f /var/lib/waydroid/images/system.img ]; then
        echo "  Downloading system image (this may take 5-10 minutes)..."
        cd /tmp
        
        # Try waydroid's Python downloader first
        python3 -c "
import urllib.request, zipfile, os, sys

def download(url, dest):
    print(f'  Downloading from {url[:60]}...')
    try:
        urllib.request.urlretrieve(url, dest)
        return True
    except Exception as e:
        print(f'  Download error: {e}')
        return False

# Try official OTA API
import json
try:
    req = urllib.request.Request('https://ota.waydro.id/system/x86_64/GAPPS')
    req.add_header('User-Agent', 'Waydroid/1.0')
    resp = urllib.request.urlopen(req, timeout=30)
    data = json.loads(resp.read())
    sys_url = data.get('url', '')
    if sys_url:
        print(f'  OTA system URL: {sys_url[:80]}')
        if download(sys_url, '/tmp/system.zip'):
            with zipfile.ZipFile('/tmp/system.zip') as z:
                z.extract('system.img', '/var/lib/waydroid/images/')
            os.remove('/tmp/system.zip')
            print('  System image extracted OK')
except Exception as e:
    print(f'  OTA API error: {e}')
    print('  Trying SourceForge fallback...')
    # Fallback disabled - too slow via SF redirects
    pass

try:
    req = urllib.request.Request('https://ota.waydro.id/vendor/x86_64/MAINLINE')
    req.add_header('User-Agent', 'Waydroid/1.0')
    resp = urllib.request.urlopen(req, timeout=30)
    data = json.loads(resp.read())
    ven_url = data.get('url', '')
    if ven_url:
        print(f'  OTA vendor URL: {ven_url[:80]}')
        if download(ven_url, '/tmp/vendor.zip'):
            with zipfile.ZipFile('/tmp/vendor.zip') as z:
                z.extract('vendor.img', '/var/lib/waydroid/images/')
            os.remove('/tmp/vendor.zip')
            print('  Vendor image extracted OK')
except Exception as e:
    print(f'  Vendor download error: {e}')
" 2>&1
    fi
}

echo ""
echo "[7] Check results..."
ls -lh /var/lib/waydroid/images/ 2>/dev/null || echo "  No images directory"
ls -la /dev/binder* /dev/binderfs/ 2>/dev/null || true

echo ""
echo "=== DONE ==="
