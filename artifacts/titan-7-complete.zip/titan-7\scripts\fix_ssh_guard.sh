#!/bin/bash
set -euo pipefail

echo "=== SSH Guard + Cron Setup ==="

# Create nftables SSH guard
mkdir -p /etc/nftables.d
cat > /etc/nftables.d/titan-ssh-guard.conf << 'EOF'
#!/usr/sbin/nft -f
table inet titan_ssh_guard {
    chain ssh_protect {
        type filter hook output priority -200; policy accept;
        tcp sport 22 accept
        tcp dport 22 accept
    }
}
EOF

nft -f /etc/nftables.d/titan-ssh-guard.conf && echo "  SSH guard nftables: ACTIVE (priority -200)" || echo "  SSH guard nftables: FAILED"

# Ensure included at boot
if [ -f /etc/nftables.conf ]; then
    if ! grep -q "titan-ssh-guard" /etc/nftables.conf 2>/dev/null; then
        echo 'include "/etc/nftables.d/titan-ssh-guard.conf"' >> /etc/nftables.conf
        echo "  Added to nftables.conf boot"
    fi
fi

# Install cron
apt-get install -y cron 2>&1 | tail -3
systemctl enable --now cron 2>/dev/null || true

# SSH watchdog
cat > /usr/local/bin/titan-ssh-watchdog.sh << 'WD'
#!/bin/bash
if ! ss -tlnp | grep -q ':22 '; then
    logger -t titan-ssh-watchdog "EMERGENCY: SSH port 22 down, flushing nftables"
    nft flush ruleset 2>/dev/null
    iptables -F 2>/dev/null
    iptables -P OUTPUT ACCEPT 2>/dev/null
    systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null
fi
WD
chmod +x /usr/local/bin/titan-ssh-watchdog.sh

# Add cron job
(crontab -l 2>/dev/null | grep -v titan-ssh-watchdog; echo "* * * * * /usr/local/bin/titan-ssh-watchdog.sh") | crontab -
echo "  SSH watchdog cron: installed (every 60s)"

# Verify
echo ""
echo "=== Verification ==="
nft list tables 2>/dev/null
echo ""
for svc in redis-server ollama xray ntfy tailscaled ssh cron; do
    STATUS=$(systemctl is-active "$svc" 2>/dev/null || echo "missing")
    printf "  %-16s %s\n" "$svc:" "$STATUS"
done
echo ""
ollama list 2>/dev/null
echo ""
df -h / | tail -1
echo ""
echo "=== DONE ==="
