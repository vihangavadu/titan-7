#!/bin/bash
set -e
export PYTHONPATH="/opt/titan:/opt/titan/core:/opt/titan/apps"

echo "=== FIX GAPS ==="

# ── 1. Create titan.env from example ──
echo "[1] Creating titan.env..."
if [ ! -f /opt/titan/config/titan.env ]; then
  if [ -f /opt/titan/config/titan.env.example ]; then
    cp /opt/titan/config/titan.env.example /opt/titan/config/titan.env
    echo "  Created titan.env from example"
  else
    touch /opt/titan/config/titan.env
    echo "  Created empty titan.env"
  fi
else
  echo "  titan.env already exists"
fi

# ── 2. AI model diagnostics ──
echo ""
echo "[2] AI Model Diagnostics..."
echo "-- titan-strategist info --"
curl -s http://127.0.0.1:11434/api/show -d '{"name":"titan-strategist"}' | python3 -c "
import sys,json
try:
    d=json.load(sys.stdin)
    print(f'  Format: {d.get(\"details\",{}).get(\"format\",\"?\")}')
    print(f'  Family: {d.get(\"details\",{}).get(\"family\",\"?\")}')
    print(f'  Params: {d.get(\"details\",{}).get(\"parameter_size\",\"?\")}')
    print(f'  Quant:  {d.get(\"details\",{}).get(\"quantization_level\",\"?\")}')
    mf = d.get('modelfile','')
    if mf:
        lines = mf.split('\n')
        for l in lines[:5]:
            print(f'  MF: {l[:100]}')
except: print('  parse error')
" 2>/dev/null

echo ""
echo "-- titan-fast info --"
curl -s http://127.0.0.1:11434/api/show -d '{"name":"titan-fast"}' | python3 -c "
import sys,json
try:
    d=json.load(sys.stdin)
    print(f'  Format: {d.get(\"details\",{}).get(\"format\",\"?\")}')
    print(f'  Family: {d.get(\"details\",{}).get(\"family\",\"?\")}')
    print(f'  Params: {d.get(\"details\",{}).get(\"parameter_size\",\"?\")}')
    print(f'  Quant:  {d.get(\"details\",{}).get(\"quantization_level\",\"?\")}')
except: print('  parse error')
" 2>/dev/null

echo ""
echo "-- Quick test with short prompt + 10s timeout --"
for model in titan-strategist titan-fast; do
  echo -n "  $model: "
  resp=$(curl -s --max-time 15 http://127.0.0.1:11434/api/generate \
    -d "{\"model\":\"$model\",\"prompt\":\"Say hello in one word.\",\"stream\":false,\"options\":{\"num_predict\":20}}" 2>/dev/null)
  answer=$(echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('response','TIMEOUT')[:80])" 2>/dev/null || echo "TIMEOUT/ERROR")
  echo "$answer"
done

# ── 3. Identify 4 apps on VPS not in src ──
echo ""
echo "[3] Apps on VPS /opt/titan/apps/ but NOT in /opt/titan/src/apps/..."
for f in /opt/titan/apps/*.py; do
  name=$(basename "$f")
  if [ ! -f "/opt/titan/src/apps/$name" ]; then
    lines=$(wc -l < "$f")
    echo "  MISSING from src: $name ($lines lines)"
  fi
done

# ── 4. Files in src but NOT synced to live ──
echo ""
echo "[4] Files in /opt/titan/src/apps/ vs /opt/titan/apps/..."
for f in /opt/titan/src/apps/*.py; do
  name=$(basename "$f")
  if [ ! -f "/opt/titan/apps/$name" ]; then
    echo "  NOT in live apps: $name"
  else
    src_size=$(wc -c < "/opt/titan/src/apps/$name")
    live_size=$(wc -c < "/opt/titan/apps/$name")
    if [ "$src_size" != "$live_size" ]; then
      echo "  SIZE MISMATCH: $name (src=$src_size live=$live_size)"
    fi
  fi
done

# ── 5. Check llm_config.json task routing structure ──
echo ""
echo "[5] llm_config.json task routing..."
python3 -c "
import json
cfg = json.load(open('/opt/titan/config/llm_config.json'))
# Find actual routing keys (not metadata)
routing = {k:v for k,v in cfg.items() if not k.startswith('_')}
print(f'  Total routing entries: {len(routing)}')
for k,v in sorted(routing.items())[:30]:
    if isinstance(v, str):
        print(f'  {k:45s} → {v}')
    elif isinstance(v, dict):
        model = v.get('model', v.get('name', str(v)[:60]))
        print(f'  {k:45s} → {model}')
" 2>/dev/null

# ── 6. Sync missing src/apps to live ──
echo ""
echo "[6] Syncing any missing src/apps → live apps..."
for f in /opt/titan/src/apps/*.py; do
  name=$(basename "$f")
  if [ ! -f "/opt/titan/apps/$name" ]; then
    cp "$f" "/opt/titan/apps/$name"
    echo "  Copied: $name"
  fi
done

# ── 7. Check local codebase dirs that should exist on VPS ──
echo ""
echo "[7] Directory structure check..."
for dir in core apps src config scripts docs training tests bin branding modelfiles iso; do
  if [ -d "/opt/titan/$dir" ]; then
    count=$(find "/opt/titan/$dir" -type f 2>/dev/null | wc -l)
    echo "  /opt/titan/$dir: $count files"
  else
    echo "  MISSING DIR: /opt/titan/$dir"
  fi
done

echo ""
echo "=== FIX GAPS COMPLETE ==="
