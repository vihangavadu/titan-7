#!/bin/bash
# FINAL boot fix - run in recovery mode
ROOT="/mnt/sdb1"

echo "=== FINAL BOOT FIX ==="

# 1. UNMASK NetworkManager - Ubuntu needs it
echo "--- 1. Unmask NetworkManager ---"
rm -f ${ROOT}/etc/systemd/system/NetworkManager.service
ln -sf /lib/systemd/system/NetworkManager.service ${ROOT}/etc/systemd/system/multi-user.target.wants/NetworkManager.service 2>/dev/null
echo "  NetworkManager UNMASKED + ENABLED"

# 2. Keep UFW masked
echo "--- 2. Keep UFW masked ---"
rm -f ${ROOT}/etc/systemd/system/multi-user.target.wants/ufw.service 2>/dev/null
ln -sf /dev/null ${ROOT}/etc/systemd/system/ufw.service
echo "  UFW masked"

# 3. Neuter nftables config (don't mask - just make it harmless)
echo "--- 3. Neuter nftables ---"
rm -f ${ROOT}/etc/systemd/system/multi-user.target.wants/nftables.service 2>/dev/null
ln -sf /dev/null ${ROOT}/etc/systemd/system/nftables.service
# Also empty the config so even if loaded, nothing happens
cat > ${ROOT}/etc/nftables.conf << 'NFTEOF'
#!/usr/sbin/nft -f
flush ruleset
# TITAN: Firewall disabled for boot stability
# Re-enable via: systemctl unmask nftables && cp /opt/titan/config/nftables.conf /etc/nftables.conf
NFTEOF
echo "  nftables masked + config emptied"

# 4. Create guaranteed-network early boot service
echo "--- 4. Create network guarantee service ---"
cat > ${ROOT}/etc/systemd/system/titan-network-guarantee.service << 'NETEOF'
[Unit]
Description=TITAN Network Guarantee - Direct IP config
DefaultDependencies=no
Before=network-pre.target
Wants=network-pre.target
After=systemd-udevd.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c 'sleep 2; ip addr add 72.62.72.48/24 dev eth0 2>/dev/null || true; ip link set eth0 up 2>/dev/null || true; ip route add default via 72.62.72.254 2>/dev/null || true; echo "[TITAN-NET] Network guaranteed"'

[Install]
WantedBy=sysinit.target
NETEOF
ln -sf /etc/systemd/system/titan-network-guarantee.service ${ROOT}/etc/systemd/system/sysinit.target.wants/titan-network-guarantee.service 2>/dev/null
mkdir -p ${ROOT}/etc/systemd/system/sysinit.target.wants 2>/dev/null
ln -sf /etc/systemd/system/titan-network-guarantee.service ${ROOT}/etc/systemd/system/sysinit.target.wants/titan-network-guarantee.service
echo "  Network guarantee service created"

# 5. Disable ALL potentially interfering Titan services
echo "--- 5. Disable interfering Titan services ---"
for svc in lucid-ebpf lucid-titan titan-first-boot titan-waydroid waydroid-container titan-dns titan-patch-bridge; do
    rm -f ${ROOT}/etc/systemd/system/multi-user.target.wants/${svc}.service 2>/dev/null
done
echo "  Disabled: lucid-ebpf, lucid-titan, titan-first-boot, titan-waydroid, waydroid-container, titan-dns, titan-patch-bridge"

# 6. Ensure SSH is definitely enabled
echo "--- 6. Ensure SSH ---"
ln -sf /lib/systemd/system/ssh.service ${ROOT}/etc/systemd/system/multi-user.target.wants/ssh.service 2>/dev/null
echo "  SSH enabled"

# 7. Set working DNS
echo "--- 7. Set DNS ---"
cat > ${ROOT}/etc/resolv.conf << 'DNSEOF'
nameserver 1.1.1.1
nameserver 8.8.4.4
nameserver 153.92.2.6
DNSEOF
# Prevent cloud-init/NM from overwriting
chattr +i ${ROOT}/etc/resolv.conf 2>/dev/null || true
echo "  DNS set + immutable"

# 8. Ensure SSH allows root login
echo "--- 8. SSH config ---"
grep -q "^PermitRootLogin yes" ${ROOT}/etc/ssh/sshd_config 2>/dev/null || echo "PermitRootLogin yes" >> ${ROOT}/etc/ssh/sshd_config
echo "  PermitRootLogin yes"

# 9. Verify final state
echo ""
echo "=== FINAL ENABLED SERVICES ==="
echo "multi-user.target.wants:"
ls ${ROOT}/etc/systemd/system/multi-user.target.wants/ 2>/dev/null | sort
echo ""
echo "sysinit.target.wants:"
ls ${ROOT}/etc/systemd/system/sysinit.target.wants/ 2>/dev/null | sort
echo ""
echo "Masked:"
find ${ROOT}/etc/systemd/system/ -maxdepth 1 -type l -lname '/dev/null' -exec basename {} \; 2>/dev/null | sort

echo ""
echo "=== FIX COMPLETE - Stop recovery and reboot ==="
