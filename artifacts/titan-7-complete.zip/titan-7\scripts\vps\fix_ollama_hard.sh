#!/bin/bash
echo "=== HARD FIX OLLAMA ==="

# Kill all ollama processes and restart clean
echo "[1] Hard kill all ollama processes..."
systemctl stop ollama
sleep 2
pkill -9 -f "ollama runner" 2>/dev/null
pkill -9 -f "ollama serve" 2>/dev/null
sleep 2
echo "  Killed. Starting fresh..."
systemctl start ollama
sleep 5
systemctl is-active ollama && echo "  ollama: active" || echo "  ollama: FAILED"

echo ""
echo "[2] Check ollama logs for errors..."
journalctl -u ollama --no-pager -n 20 2>/dev/null | tail -15

echo ""
echo "[3] Verify models exist..."
ollama list 2>/dev/null

echo ""
echo "[4] Test base model first (45s timeout, cold start)..."
echo -n "  qwen2.5:7b: "
resp=$(curl -s --max-time 45 http://127.0.0.1:11434/api/generate \
  -d '{"model":"qwen2.5:7b","prompt":"Say hello","stream":false,"options":{"num_predict":5}}' 2>/dev/null)
if [ -z "$resp" ]; then
  echo "TIMEOUT"
else
  echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'{d.get(\"response\",\"?\")[:60]} (load={d.get(\"load_duration\",0)/1e9:.1f}s eval={d.get(\"eval_duration\",0)/1e9:.1f}s)')" 2>/dev/null || echo "PARSE_ERR"
fi

echo ""
echo "[5] Test titan-analyst (45s timeout, cold start)..."
echo -n "  titan-analyst: "
resp=$(curl -s --max-time 45 http://127.0.0.1:11434/api/generate \
  -d '{"model":"titan-analyst","prompt":"Say hello","stream":false,"options":{"num_predict":5}}' 2>/dev/null)
if [ -z "$resp" ]; then
  echo "TIMEOUT"
else
  echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'{d.get(\"response\",\"?\")[:60]} (load={d.get(\"load_duration\",0)/1e9:.1f}s eval={d.get(\"eval_duration\",0)/1e9:.1f}s)')" 2>/dev/null || echo "PARSE_ERR"
fi

echo ""
echo "[6] Test titan-fast (45s timeout, cold start)..."
echo -n "  titan-fast: "
resp=$(curl -s --max-time 45 http://127.0.0.1:11434/api/generate \
  -d '{"model":"titan-fast","prompt":"Say hello","stream":false,"options":{"num_predict":5}}' 2>/dev/null)
if [ -z "$resp" ]; then
  echo "TIMEOUT"
else
  echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'{d.get(\"response\",\"?\")[:60]} (load={d.get(\"load_duration\",0)/1e9:.1f}s eval={d.get(\"eval_duration\",0)/1e9:.1f}s)')" 2>/dev/null || echo "PARSE_ERR"
fi

echo ""
echo "[7] Test titan-strategist (45s timeout, cold start)..."
echo -n "  titan-strategist: "
resp=$(curl -s --max-time 45 http://127.0.0.1:11434/api/generate \
  -d '{"model":"titan-strategist","prompt":"Say hello","stream":false,"options":{"num_predict":5}}' 2>/dev/null)
if [ -z "$resp" ]; then
  echo "TIMEOUT"
else
  echo "$resp" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'{d.get(\"response\",\"?\")[:60]} (load={d.get(\"load_duration\",0)/1e9:.1f}s eval={d.get(\"eval_duration\",0)/1e9:.1f}s)')" 2>/dev/null || echo "PARSE_ERR"
fi

echo ""
echo "[8] Currently loaded models..."
curl -s http://127.0.0.1:11434/api/ps 2>/dev/null | python3 -c "
import sys,json
d=json.load(sys.stdin)
for m in d.get('models',[]):
    print(f'  {m.get(\"name\",\"?\")}: {m.get(\"size\",0)/1e9:.1f}GB')
" 2>/dev/null || echo "  none"

echo ""
echo "[9] Memory..."
free -h | head -2

echo ""
echo "=== DONE ==="
