#!/bin/bash
# DEPRECATED — This file has been neutralized for security.
# Hardcoded credentials and IPs have been removed.
# Use SSH keys for authentication: ssh-copy-id root@YOUR_VPS_IP
echo 'ERROR: This script is deprecated. Use SSH keys for authentication.'
exit 1
